//
//  BaseViewController.swift
//  VK
//
//  Created by Павел Власов on 08.10.2021.
//

import UIKit


class BaseViewController: UITabBarController {

override func viewDidLoad() {
    super.viewDidLoad()
}


}
