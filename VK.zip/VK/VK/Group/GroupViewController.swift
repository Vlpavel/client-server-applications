//
//  GroupViewController.swift
//  VK
//
//  Created by Павел Власов on 08.10.2021.
//

import UIKit

class GroupViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    
    
    var groupArray = [Group]()
    
    // @IBAction func pressedButtonAllGroup(_ sender: Any) {
    //     let allGroupController = AllGroupViewController()
    //     self.navigationController?.pushViewController(allGroupController, animated: true)
    // }
    
    
    
    @IBOutlet weak var groupTableView: UITableView!
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groupArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: R.cell.one, for: indexPath) as! OneTableViewCell
        cell.configure(group: groupArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle {
        case.delete:
            self.groupArray.remove(at: indexPath.row)
            self.groupTableView.deleteRows(at: [indexPath], with: .automatic)
            
        default:
            break
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let gradient = CAGradientLayer()  //создание градиента
        gradient.colors = [UIColor.systemPurple.cgColor,
                           UIColor.systemGreen.cgColor]  //цвета
        gradient.locations = [0, 1]  //где цвета
        gradient.startPoint = CGPoint.zero  //начало
        gradient.endPoint = CGPoint(x: 0, y: 1)  //конец
        gradient.frame = self.view.bounds
        gradient.zPosition = 0  //какой слой вью
        self.view.layer.addSublayer(gradient)
        
        groupTableView.layer.zPosition = 1
        
        groupTableView.register(UINib(nibName: R.cell.one, bundle: nil), forCellReuseIdentifier: R.cell.one)
        groupTableView.delegate = self
        groupTableView.dataSource = self
    }
    
    func isItemAlreadyInArray(group: Group) -> Bool {
        return groupArray.contains { sourceGroup in
            sourceGroup.title == group.title
        }
    }
    
    @IBAction func unwindSegueToMyGroup(segue: UIStoryboardSegue) {  //escape
        if segue.identifier == fromAllGroupsToMyGroups,
           let sourceVC = segue.source as? AllGroupViewController,
           let selectedGroup = sourceVC.selectedGroup
        {
            if isItemAlreadyInArray(group: selectedGroup) {return}
            self.groupArray.append(selectedGroup)
            groupTableView.reloadData()
        }
    }
    
    
}

struct Group {
    var  title = String()
    var avatar = UIImage()
}
