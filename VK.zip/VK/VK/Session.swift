//
//  Session.swift
//  VK
//
//  Created by Павел Власов on 22.11.2021.
//

import Foundation


class Session {
    
    var token: String = ""
    var userID: String = ""
    
}
