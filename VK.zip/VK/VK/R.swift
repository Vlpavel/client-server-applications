//
//  R.swift
//  VK
//
//  Created by Павел Власов on 11.10.2021.
//

import UIKit

enum R {
    enum cell {
        
        static let one: String = "OneTableViewCell"
        static let gallery: String = "GalleryCollectionCell"
        //static let like: String = "LikeCounterView"
        
    }
}

let fromAllGroupsToMyGroups = "fromAllGroupsToMyGroups"


enum custom {   //кастомизация(тень)
    func addShadow(view: UIView) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = CGSize(width: 10, height: 10)
        view.layer.shadowRadius = 5
        view.layer.shadowOpacity = 1
    }
}
