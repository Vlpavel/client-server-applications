//
//  GalleryViewController.swift
//  VK
//
//  Created by Павел Власов on 14.10.2021.
//

import UIKit

class GalleryViewController: UIViewController {
    
    @IBOutlet weak var galleryView: GalleryHorisontalView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let images = [UIImage(named: "Троль.png")!, UIImage(named: "Троль.png")!, UIImage(named: "Троль.png")!, UIImage(named: "Троль.png")!, UIImage(named: "Троль.png")!]
        galleryView.setImages(images: images)
        galleryView.layer.zPosition = 1
    //var photos = [UIImage(named: "Троль.png")!, UIImage(named: "Троль.png")!, UIImage(named: "Троль.png")!, UIImage(named: "Троль.png")!]
    
    
   
        
        let gradient = CAGradientLayer()  //создание градиента
        gradient.colors = [UIColor.systemPurple.cgColor,
                           UIColor.systemGreen.cgColor]  //цвета
        gradient.locations = [0, 1]  //где цвета
        gradient.startPoint = CGPoint.zero  //начало
        gradient.endPoint = CGPoint(x: 0, y: 1)  //конец
        gradient.frame = self.view.bounds
        gradient.zPosition = 0  //какой слой вью
        self.view.layer.addSublayer(gradient)
        
    }
}
