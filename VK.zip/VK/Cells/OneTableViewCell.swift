//
//  OneTableViewCell.swift
//  VK
//
//  Created by Павел Власов on 11.10.2021.
//

import UIKit

class OneTableViewCell: UITableViewCell {
    
    
    
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
    
    
    
    override func prepareForReuse() {
        myImage.image = nil
        myLabel.text = nil
    }
    
    
    func configure(friend: Friend) {
        myImage.image = friend.avatar
        myLabel.text = friend.name
    }
    
    func configure(group: Group) {
        myImage.image = group.avatar
        myLabel.text = group.title
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        myImage.layer.cornerRadius = 20
        //    myImage.layer.shadowColor = UIColor.black.cgColor
        //    myImage.layer.shadowOffset = CGSize(width: 10, height: 10)
        //    myImage.layer.shadowRadius = 5
        //    myImage.layer.shadowOpacity = 1
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    
    
    @IBAction func pressAvatarButton(_ sender: Any) {
        
        let scale = CGFloat(10)
        
        UIView.animate(withDuration: 1) { [weak self] in   //анимация сжатия
            guard let self = self else {return}
            
            self.myImage.frame = CGRect(x: self.myImage.frame.origin.x - scale / 2, y: self.myImage.frame.origin.y - scale / 2, width: self.myImage.frame.width + scale, height: self.myImage.frame.height + scale)
        } completion: { isSuccessfully in
            UIView.animate(withDuration: 1,    //пружинная анимация
                           delay: 0,
                           usingSpringWithDamping: 0.3,
                           initialSpringVelocity: 0.7,
                           options: []) { [weak self] in
                guard let self = self else {return}
                
                self.myImage.frame = CGRect(x: self.myImage.frame.origin.x + scale / 2, y: self.myImage.frame.origin.y + scale / 2, width: self.myImage.frame.width - scale, height: self.myImage.frame.height - scale)
            } completion: { _ in
                
            }
        }
        
    }
    
    
    
    
    
    
    
    
}

