//
//  GalleryCollectionCell.swift
//  VK
//
//  Created by Павел Власов on 22.10.2021.
//

import UIKit

class GalleryCollectionCell: UICollectionViewCell {
    
    
    @IBOutlet weak var photoImageView: UIImageView!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.photoImageView.image = nil
    }
    
    func configure(image: UIImage) {
        photoImageView.image = image
        
        
        
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func pressPictures(_ sender: Any) {
        
  //      let scale = CGFloat(100)
  //
  //      UIView.animate(withDuration: 1) { [weak self] in   //анимация сжатия
  //          guard let self = self else {return}
  //
  //          self.photoImageView.frame = CGRect(x: self.photoImageView.frame.origin.x + scale, y: self.photoImageView.frame.origin.y + scale * 2, width: self.photoImageView.frame.width + scale, height: self.photoImageView.frame.height + scale)
 //       } completion: { isSuccessfully in
 //
 //       }
    }
    
    
    
    
    
    
    
}
